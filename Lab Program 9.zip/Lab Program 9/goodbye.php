<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	Wait for Your Result..

</body>
</html>